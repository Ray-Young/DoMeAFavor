package client;

public class Test {
	public static void main(String[] args) {
		 GetUser getUser = new GetUser();
		 getUser.getUser("lei");
		// getUser.getUser("l9s");

//		PostUser postUser = new PostUser();
//		postUser.createUser("aaa");
	}

}
